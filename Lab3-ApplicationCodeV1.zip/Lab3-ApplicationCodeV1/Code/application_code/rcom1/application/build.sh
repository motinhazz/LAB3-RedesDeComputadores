#!/usr/bin/env bash
gcc -w main.c ../protocol/*.o -o main
