#ifndef linklayer
#define linklayer

#include <termios.h>

#define BAUDRATE B38400
#define FLAG 0x5c
#define A_TRANSMITTER 0x03
#define A_RECEIVER 0x01
#define C_SET 0x07
#define C_UA 0x06
#define C_DISC 0x0B
#define C_RR 0x05
#define C_REJ 0x09

#define MAX_PAYLOAD_SIZE 256

struct linkLayer {
    char serialPort[20];
    int baudRate;
    unsigned int sequenceNumber;
    unsigned int timeout;
    unsigned int numTransmissions;
    int role; // 0:Transmitter, 1:Receiver
};

int llopen(struct linkLayer ll);
int llclose(int fd, int showStatistics);
int llwrite(int fd, const char *buffer, int length);
int llread(int fd, char *buffer);

#endif