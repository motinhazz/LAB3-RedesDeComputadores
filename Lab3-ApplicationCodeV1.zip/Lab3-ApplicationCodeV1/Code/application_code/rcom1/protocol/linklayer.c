
int llopen(const char *device) {
    int fd = open(device, O_RDWR | O_NOCTTY);
    if (fd < 0) {
        perror(device);
        return -1;
    }

    struct termios oldtio;
    setup_serial(fd, &oldtio);

    unsigned char set_frame[5] = {FLAG, A_TRANSMITTER, C_SET, A_TRANSMITTER ^ C_SET, FLAG};
    write(fd, set_frame, 5);

    unsigned char ua_frame[5];
    State currentState = START;
    while (STOP == FALSE) {
        int res = read(fd, ua_frame, 1);
        if (res != 1) {
            currentState = START;
            continue;
        }

        switch (currentState) {
            case START:
                if (ua_frame[0] == FLAG) currentState = FLAG_RCV;
                break;
            case FLAG_RCV:
                if (ua_frame[0] == A_RECEIVER) {
                    currentState = A_RCV;
                } else if (ua_frame[0] != FLAG) {
                    currentState = START;
                }
                break;
            case A_RCV:
                if (ua_frame[0] == C_UA) {
                    currentState = C_RCV;
                } else if (ua_frame[0] == FLAG) {
                    currentState = FLAG_RCV;
                } else {
                    currentState = START;
                }
                break;
            case C_RCV:
                if (ua_frame[0] == (A_RECEIVER ^ C_UA)) {
                    currentState = BCC_OK;
                } else if (ua_frame[0] == FLAG) {
                    currentState = FLAG_RCV;
                } else {
                    currentState = START;
                }
                break;
            case BCC_OK:
                if (ua_frame[0] == FLAG) {
                    STOP = TRUE;
                } else {
                    currentState = START;
                }
                break;
        }
    }

    if (currentState != BCC_OK) {
        close(fd);
        return -1;
    }

    return fd;
}

int llclose(int fd) {
    unsigned char disc_frame[5] = {FLAG, A_TRANSMITTER, C_DISC, A_TRANSMITTER ^ C_DISC, FLAG};
    write(fd, disc_frame, 5);

    unsigned char ua_frame[5];
    State currentState = START;
    while (STOP == FALSE) {
        int res = read(fd, ua_frame, 1);
        if (res != 1) {
            currentState = START;
            continue;
        }

        switch (currentState) {
            case START:
                if (ua_frame[0] == FLAG) currentState = FLAG_RCV;
                break;
            case FLAG_RCV:
                if (ua_frame[0] == A_RECEIVER) {
                    currentState = A_RCV;
                } else if (ua_frame[0] != FLAG) {
                    currentState = START;
                }
                break;
            case A_RCV:
                if (ua_frame[0] == C_UA) {
                    currentState = C_RCV;
                } else if (ua_frame[0] == FLAG) {
                    currentState = FLAG_RCV;
                } else {
                    currentState = START;
                }
                break;
            case C_RCV:
                if (ua_frame[0] == (A_RECEIVER ^ C_UA)) {
                    currentState = BCC_OK;
                } else if (ua_frame[0] == FLAG) {
                    currentState = FLAG_RCV;
                } else {
                    currentState = START;
                }
                break;
            case BCC_OK:
                if (ua_frame[0] == FLAG) {
                    STOP = TRUE;
                } else {
                    currentState = START;
                }
                break;
        }
    }

    close(fd);
    return 0;
}

int llwrite(int fd, const char *buffer, int length) {
    unsigned char frame[FRAME_SIZE];
    int bytesWritten = 0;

    while (bytesWritten < length) {
        int dataSize = length - bytesWritten > FRAME_SIZE - 6 ? FRAME_SIZE - 6 : length - bytesWritten;
        frame[0] = FLAG;
        frame[1] = A_TRANSMITTER;
        frame[2] = C_SET;
        frame[3] = frame[1] ^ frame[2]; // BCC1
        memcpy(&frame[4], buffer + bytesWritten, dataSize);
        frame[4 + dataSize] = FLAG;

        if (write(fd, frame, 5 + dataSize) < 0) {
            return -1;
        }

        // Wait for RR (Receiver Ready) frame
        unsigned char ack[5];
        State currentState = START;
        STOP = FALSE;
        while (STOP == FALSE) {
            int res = read(fd, ack, 1);
            if (res != 1) {
                currentState = START;
                continue;
            }

            switch (currentState) {
                case START:
                    if (ack[0] == FLAG) currentState = FLAG_RCV;
                    break;
                case FLAG_RCV:
                    if (ack[0] == A_RECEIVER) {
                        currentState = A_RCV;
                    } else if (ack[0] != FLAG) {
                        currentState = START;
                    }
                    break;
                case A_RCV:
                    if (ack[0] == C_RR) {
                        currentState = C_RCV;
                    } else if (ack[0] == FLAG) {
                        currentState = FLAG_RCV;
                    } else {
                        currentState = START;
                    }
                    break;
                case C_RCV:
                    if (ack[0] == (A_RECEIVER ^ C_RR)) {
                        currentState = BCC_OK;
                    } else if (ack[0] == FLAG) {
                        currentState = FLAG_RCV;
                    } else {
                        currentState = START;
                    }
                    break;
                case BCC_OK:
                    if (ack[0] == FLAG) {
                        STOP = TRUE;
                    } else {
                        currentState = START;
                    }
                    break;
            }
        }

        if (currentState != BCC_OK) {
            return -1;
        }

        bytesWritten += dataSize;
    }

    return length;
}

int llread(int fd, char *buffer, int bufferSize) {
    State currentState = START;
    int index = 0;
    unsigned char byte;
    unsigned char data_frame[FRAME_SIZE];
    STOP = FALSE;

    while (STOP == FALSE && index < bufferSize) {
        int res = read(fd, &byte, 1);
        if (res != 1) {
            currentState = START;
            continue;
        }

        switch (currentState) {
            case START:
                if (byte == FLAG) currentState = FLAG_RCV;
                break;
            case FLAG_RCV:
                if (byte == A_TRANSMITTER) {
                    currentState = A_RCV;
                } else if (byte != FLAG) {
                    currentState = START;
                }
                break;
            case A_RCV:
                if (byte == C_SET) {
                    currentState = C_RCV;
                } else if (byte == FLAG) {
                    currentState = FLAG_RCV;
                } else {
                    currentState = START;
                }
                break;
            case C_RCV:
                if (byte == (A_TRANSMITTER ^ C_SET)) {
                    currentState = BCC_OK;
                } else if (byte == FLAG) {
                    currentState = FLAG_RCV;
                } else {
                    currentState = START;
                }
                break;
            case BCC_OK:
                if (byte == FLAG) {
                    STOP = TRUE;
                } else {
                    data_frame[index++] = byte;
                }
                break;
        }
    }

    if (currentState != BCC_OK) {
        return -1;
    }

    memcpy(buffer, data_frame, index);

    unsigned char rr_frame[5] = {FLAG, A_RECEIVER, C_RR, A_RECEIVER ^ C_RR, FLAG};
    write(fd, rr_frame, 5);

    return index;
}